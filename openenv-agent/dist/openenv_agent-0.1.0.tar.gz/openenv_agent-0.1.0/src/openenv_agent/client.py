"""OpenEnv client for connecting to OpenEnv servers."""

import json
import logging
from dataclasses import dataclass
from typing import Any, Optional, Tuple

import httpx

logger = logging.getLogger(__name__)


@dataclass
class EnvResponse:
    """Response from an OpenEnv environment step."""
    observation: dict
    reward: float
    done: bool
    info: dict


class OpenEnvClient:
    """
    Client for connecting to OpenEnv servers.

    Provides a Gymnasium-style API (reset, step, state) for interacting
    with OpenEnv RL environments over HTTP.
    """

    def __init__(
        self,
        base_url: str,
        timeout: float = 30.0,
        api_key: Optional[str] = None,
    ):
        """
        Initialize the OpenEnv client.

        Args:
            base_url: Base URL of the OpenEnv server (e.g., "http://localhost:8000")
            timeout: Request timeout in seconds
            api_key: Optional API key for authentication
        """
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._client = httpx.Client(timeout=timeout)
        if api_key:
            self._client.headers["Authorization"] = f"Bearer {api_key}"

    def reset(self) -> dict:
        """
        Reset the environment and return the initial observation.

        Returns:
            dict: Initial observation from the environment
        """
        try:
            response = self._client.post(f"{self.base_url}/reset")
            response.raise_for_status()
            data = response.json()
            return data.get("observation", data)
        except httpx.HTTPError as e:
            logger.error(f"Failed to reset environment: {e}")
            raise

    def step(self, action: Any) -> Tuple[dict, float, bool, dict]:
        """
        Execute an action in the environment.

        Args:
            action: Action to take (dict or object with as_dict method)

        Returns:
            Tuple of (observation, reward, done, info)
        """
        if hasattr(action, "as_dict"):
            action_dict = action.as_dict()
        elif isinstance(action, dict):
            action_dict = action
        else:
            raise ValueError(f"Action must be dict or have as_dict() method, got {type(action)}")

        try:
            response = self._client.post(
                f"{self.base_url}/step",
                json={"action": action_dict},
            )
            response.raise_for_status()
            data = response.json()
            return (
                data.get("observation", {}),
                data.get("reward", 0.0),
                data.get("done", False),
                data.get("info", {}),
            )
        except httpx.HTTPError as e:
            logger.error(f"Failed to step environment: {e}")
            raise

    def state(self) -> dict:
        """
        Get the current state of the environment without taking an action.

        Returns:
            dict: Current environment state
        """
        try:
            response = self._client.get(f"{self.base_url}/state")
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Failed to get state: {e}")
            raise

    def health(self) -> bool:
        """
        Check if the environment server is healthy.

        Returns:
            bool: True if server is healthy, False otherwise
        """
        try:
            response = self._client.get(f"{self.base_url}/health")
            return response.status_code == 200
        except httpx.HTTPError:
            return False

    def close(self):
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False


class AsyncOpenEnvClient:
    """
    Async client for connecting to OpenEnv servers.
    """

    def __init__(
        self,
        base_url: str,
        timeout: float = 30.0,
        api_key: Optional[str] = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._client = httpx.AsyncClient(timeout=timeout)
        if api_key:
            self._client.headers["Authorization"] = f"Bearer {api_key}"

    async def reset(self) -> dict:
        try:
            response = await self._client.post(f"{self.base_url}/reset")
            response.raise_for_status()
            data = response.json()
            return data.get("observation", data)
        except httpx.HTTPError as e:
            logger.error(f"Failed to reset environment: {e}")
            raise

    async def step(self, action: Any) -> Tuple[dict, float, bool, dict]:
        if hasattr(action, "as_dict"):
            action_dict = action.as_dict()
        elif isinstance(action, dict):
            action_dict = action
        else:
            raise ValueError(f"Action must be dict or have as_dict() method, got {type(action)}")

        try:
            response = await self._client.post(
                f"{self.base_url}/step",
                json={"action": action_dict},
            )
            response.raise_for_status()
            data = response.json()
            return (
                data.get("observation", {}),
                data.get("reward", 0.0),
                data.get("done", False),
                data.get("info", {}),
            )
        except httpx.HTTPError as e:
            logger.error(f"Failed to step environment: {e}")
            raise

    async def state(self) -> dict:
        try:
            response = await self._client.get(f"{self.base_url}/state")
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Failed to get state: {e}")
            raise

    async def aclose(self):
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.aclose()
        return False